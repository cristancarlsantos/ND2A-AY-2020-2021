﻿/*19-06678
* Cristan Carl Santos
* ND2A
* This program will display "Hello World"
*/

using System;


namespace Sample3_InputMyName
{

   public static class Program
   {
       public static void Main()
       {

           Console.WriteLine("Enter your name: ");
           string name = Console.ReadLine();
           Console.WriteLine("Hello " + name + "!!!");
           Console.WriteLine(" WELCOME TO OOP environment");

           Console.ReadKey();

       }
   }
}