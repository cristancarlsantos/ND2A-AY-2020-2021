﻿/*19-06678
* Cristan Carl Santos
* ND2A
* This program will display "Hello World"
*/

using System;


namespace Sample2_MyProfile
{

   public static class Program
   {
       public static void Main()
       {
           string name = "Crsitan Carl Santos";
           string birthdate = "August 11, 2000";
           string course = "Bachelor of Science Major in Network and Data Communication";
           int year = 2;
           string section = "A";

           Console.WriteLine("Member 1");
           Console.WriteLine("Name : ");
           Console.WriteLine(name);
           Console.WriteLine("Date of Birth : ");
           Console.WriteLine(birthdate);
           Console.WriteLine("Course : ");
           Console.WriteLine(course);
           Console.WriteLine("Year : ");
           Console.WriteLine(year);
           Console.WriteLine("Section : ");
           Console.WriteLine(section);

           Console.ReadKey();
           Console.ReadKey();

       }
   }
}