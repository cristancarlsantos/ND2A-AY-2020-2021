﻿ /*19-06678
* Cristan Carl Santos
* ND2A
* This program will display "Hello World"
*/

using System;


namespace Sample1_HelloWorld
{
   class HelloWorld
   {
       static void Main(string[] args)
       {
           System.Console.WriteLine("Hello World");
           System.Console.ReadKey();
       }
   }
}