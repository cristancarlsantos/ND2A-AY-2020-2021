﻿using System;

namespace ClassExample1
{
    class MyProfile
    {
        public void DisplayProfile()
        {
            System.Console.WriteLine("\n\n\n\t    P R O F I L E\n");
            System.Console.WriteLine("Name\t :  Cristan Carl Sioson Santos\n");
            System.Console.WriteLine("Birthday :  August 11, 2000\n");
            System.Console.WriteLine("Course\t :  BS in Computer Science Major in Network" + " and Data Communication\n");
            System.Console.WriteLine("Year\t :  2nd\n");
            System.Console.WriteLine("Section\t :  A\n");
            System.Console.ReadLine();
        }
    }
}
