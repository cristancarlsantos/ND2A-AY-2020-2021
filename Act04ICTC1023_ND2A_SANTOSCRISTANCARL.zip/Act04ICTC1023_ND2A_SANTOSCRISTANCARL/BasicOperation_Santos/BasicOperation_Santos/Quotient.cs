﻿using System;


namespace BasicOperation_Santos
{
    class Quotient
    {
        public void ComputeQuotient()
        {
            DeclareVar.quotient = DeclareVar.num1 / DeclareVar.num2;
            System.Console.WriteLine("\nThe quotient is " + DeclareVar.quotient);
        }
    }
}
