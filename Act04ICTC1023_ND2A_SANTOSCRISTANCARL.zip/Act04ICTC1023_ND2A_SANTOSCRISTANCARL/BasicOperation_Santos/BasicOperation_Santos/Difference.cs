﻿using System;

namespace BasicOperation_Santos
{
    class Difference
    {
        public void ComputeDifference()
        {
            DeclareVar.difference = DeclareVar.num1 - DeclareVar.num2;
            System.Console.WriteLine("\nThe difference is " + DeclareVar.difference);
        }
    }
}

